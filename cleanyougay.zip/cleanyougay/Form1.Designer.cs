﻿
namespace cleanyougay
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_panel = new System.Windows.Forms.Panel();
            this.comment_del = new System.Windows.Forms.Button();
            this.post_del = new System.Windows.Forms.Button();
            this.text = new System.Windows.Forms.TextBox();
            this.login_panel = new System.Windows.Forms.Panel();
            this.login = new System.Windows.Forms.Button();
            this.password = new System.Windows.Forms.TextBox();
            this.ID = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.avg_del_time = new System.Windows.Forms.Label();
            this.expect_time = new System.Windows.Forms.Label();
            this.progress_status_panel = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.main_panel.SuspendLayout();
            this.login_panel.SuspendLayout();
            this.progress_status_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // main_panel
            // 
            this.main_panel.Controls.Add(this.comment_del);
            this.main_panel.Controls.Add(this.post_del);
            this.main_panel.Controls.Add(this.text);
            this.main_panel.Location = new System.Drawing.Point(12, 12);
            this.main_panel.Name = "main_panel";
            this.main_panel.Size = new System.Drawing.Size(270, 100);
            this.main_panel.TabIndex = 0;
            // 
            // comment_del
            // 
            this.comment_del.Location = new System.Drawing.Point(186, 31);
            this.comment_del.Name = "comment_del";
            this.comment_del.Size = new System.Drawing.Size(79, 23);
            this.comment_del.TabIndex = 2;
            this.comment_del.Text = "댓글삭제";
            this.comment_del.UseVisualStyleBackColor = true;
            this.comment_del.Click += new System.EventHandler(this.comment_del_Click);
            // 
            // post_del
            // 
            this.post_del.Location = new System.Drawing.Point(186, 5);
            this.post_del.Name = "post_del";
            this.post_del.Size = new System.Drawing.Size(79, 23);
            this.post_del.TabIndex = 2;
            this.post_del.Text = "게시글 삭제";
            this.post_del.UseVisualStyleBackColor = true;
            this.post_del.Click += new System.EventHandler(this.post_del_Click);
            // 
            // text
            // 
            this.text.Location = new System.Drawing.Point(3, 7);
            this.text.Multiline = true;
            this.text.Name = "text";
            this.text.Size = new System.Drawing.Size(177, 90);
            this.text.TabIndex = 0;
            // 
            // login_panel
            // 
            this.login_panel.Controls.Add(this.login);
            this.login_panel.Controls.Add(this.password);
            this.login_panel.Controls.Add(this.ID);
            this.login_panel.Controls.Add(this.label2);
            this.login_panel.Controls.Add(this.label1);
            this.login_panel.Location = new System.Drawing.Point(11, 9);
            this.login_panel.Name = "login_panel";
            this.login_panel.Size = new System.Drawing.Size(268, 100);
            this.login_panel.TabIndex = 0;
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(179, 70);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(75, 23);
            this.login.TabIndex = 2;
            this.login.Text = "로그인";
            this.login.UseVisualStyleBackColor = true;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(94, 40);
            this.password.Name = "password";
            this.password.PasswordChar = '●';
            this.password.Size = new System.Drawing.Size(100, 21);
            this.password.TabIndex = 1;
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(94, 14);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(100, 21);
            this.ID.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "비밀번호";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "아이디";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(34, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "평균삭제시간";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "완료예상시간";
            // 
            // avg_del_time
            // 
            this.avg_del_time.AutoSize = true;
            this.avg_del_time.Location = new System.Drawing.Point(117, 30);
            this.avg_del_time.Name = "avg_del_time";
            this.avg_del_time.Size = new System.Drawing.Size(25, 12);
            this.avg_del_time.TabIndex = 0;
            this.avg_del_time.Text = "null";
            // 
            // expect_time
            // 
            this.expect_time.AutoSize = true;
            this.expect_time.Location = new System.Drawing.Point(117, 53);
            this.expect_time.Name = "expect_time";
            this.expect_time.Size = new System.Drawing.Size(25, 12);
            this.expect_time.TabIndex = 0;
            this.expect_time.Text = "null";
            // 
            // progress_status_panel
            // 
            this.progress_status_panel.Controls.Add(this.label3);
            this.progress_status_panel.Controls.Add(this.label6);
            this.progress_status_panel.Controls.Add(this.label5);
            this.progress_status_panel.Controls.Add(this.avg_del_time);
            this.progress_status_panel.Controls.Add(this.label4);
            this.progress_status_panel.Controls.Add(this.expect_time);
            this.progress_status_panel.Location = new System.Drawing.Point(15, 118);
            this.progress_status_panel.Name = "progress_status_panel";
            this.progress_status_panel.Size = new System.Drawing.Size(228, 117);
            this.progress_status_panel.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(148, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 12);
            this.label6.TabIndex = 0;
            this.label6.Text = "분 후 완료";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(148, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "ms";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(287, 239);
            this.Controls.Add(this.progress_status_panel);
            this.Controls.Add(this.login_panel);
            this.Controls.Add(this.main_panel);
            this.Name = "Form1";
            this.Text = "클린유게";
            this.main_panel.ResumeLayout(false);
            this.main_panel.PerformLayout();
            this.login_panel.ResumeLayout(false);
            this.login_panel.PerformLayout();
            this.progress_status_panel.ResumeLayout(false);
            this.progress_status_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel main_panel;
        private System.Windows.Forms.Panel login_panel;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.TextBox ID;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button comment_del;
        private System.Windows.Forms.Button post_del;
        private System.Windows.Forms.TextBox text;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label avg_del_time;
        private System.Windows.Forms.Label expect_time;
        private System.Windows.Forms.Panel progress_status_panel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

