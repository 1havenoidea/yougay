﻿namespace ruriclean
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.login_panel = new System.Windows.Forms.Panel();
            this.login = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ID = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.TextBox();
            this.text = new System.Windows.Forms.TextBox();
            this.post_del = new System.Windows.Forms.Button();
            this.comment_del = new System.Windows.Forms.Button();
            this.del_panel = new System.Windows.Forms.Panel();
            this.plus_delay = new System.Windows.Forms.Button();
            this.login_panel.SuspendLayout();
            this.del_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // login_panel
            // 
            this.login_panel.Controls.Add(this.login);
            this.login_panel.Controls.Add(this.label2);
            this.login_panel.Controls.Add(this.label1);
            this.login_panel.Controls.Add(this.ID);
            this.login_panel.Controls.Add(this.password);
            this.login_panel.Location = new System.Drawing.Point(12, 12);
            this.login_panel.Name = "login_panel";
            this.login_panel.Size = new System.Drawing.Size(259, 100);
            this.login_panel.TabIndex = 0;
            this.login_panel.Paint += new System.Windows.Forms.PaintEventHandler(this.login_panel_Paint);
            // 
            // login
            // 
            this.login.Location = new System.Drawing.Point(6, 74);
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(75, 23);
            this.login.TabIndex = 5;
            this.login.Text = "로그인";
            this.login.UseVisualStyleBackColor = true;
            this.login.Click += new System.EventHandler(this.login_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 4;
            this.label2.Text = "아이디";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(4, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "비밀번호";
            // 
            // ID
            // 
            this.ID.Location = new System.Drawing.Point(86, 3);
            this.ID.Name = "ID";
            this.ID.Size = new System.Drawing.Size(137, 21);
            this.ID.TabIndex = 1;
            // 
            // password
            // 
            this.password.Location = new System.Drawing.Point(86, 30);
            this.password.Name = "password";
            this.password.PasswordChar = '*';
            this.password.Size = new System.Drawing.Size(137, 21);
            this.password.TabIndex = 2;
            // 
            // text
            // 
            this.text.Location = new System.Drawing.Point(3, 3);
            this.text.Multiline = true;
            this.text.Name = "text";
            this.text.Size = new System.Drawing.Size(185, 103);
            this.text.TabIndex = 6;
            // 
            // post_del
            // 
            this.post_del.Location = new System.Drawing.Point(191, 4);
            this.post_del.Name = "post_del";
            this.post_del.Size = new System.Drawing.Size(86, 23);
            this.post_del.TabIndex = 7;
            this.post_del.Text = "게시글 삭제";
            this.post_del.UseVisualStyleBackColor = true;
            this.post_del.Click += new System.EventHandler(this.post_del_Click);
            // 
            // comment_del
            // 
            this.comment_del.Location = new System.Drawing.Point(191, 33);
            this.comment_del.Name = "comment_del";
            this.comment_del.Size = new System.Drawing.Size(86, 23);
            this.comment_del.TabIndex = 8;
            this.comment_del.Text = "댓글삭제";
            this.comment_del.UseVisualStyleBackColor = true;
            this.comment_del.Click += new System.EventHandler(this.comment_del_Click);
            // 
            // del_panel
            // 
            this.del_panel.Controls.Add(this.plus_delay);
            this.del_panel.Controls.Add(this.comment_del);
            this.del_panel.Controls.Add(this.text);
            this.del_panel.Controls.Add(this.post_del);
            this.del_panel.Location = new System.Drawing.Point(12, 12);
            this.del_panel.Name = "del_panel";
            this.del_panel.Size = new System.Drawing.Size(284, 113);
            this.del_panel.TabIndex = 6;
            // 
            // plus_delay
            // 
            this.plus_delay.Location = new System.Drawing.Point(202, 91);
            this.plus_delay.Name = "plus_delay";
            this.plus_delay.Size = new System.Drawing.Size(75, 23);
            this.plus_delay.TabIndex = 7;
            this.plus_delay.Text = "딜레이추가";
            this.plus_delay.UseVisualStyleBackColor = true;
            this.plus_delay.Click += new System.EventHandler(this.plus_delay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(298, 132);
            this.Controls.Add(this.login_panel);
            this.Controls.Add(this.del_panel);
            this.Name = "Form1";
            this.Text = "루리웹클리너";
            this.login_panel.ResumeLayout(false);
            this.login_panel.PerformLayout();
            this.del_panel.ResumeLayout(false);
            this.del_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel login_panel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ID;
        private System.Windows.Forms.TextBox password;
        private System.Windows.Forms.Button login;
        private System.Windows.Forms.TextBox text;
        private System.Windows.Forms.Button post_del;
        private System.Windows.Forms.Button comment_del;
        private System.Windows.Forms.Panel del_panel;
        private System.Windows.Forms.Button plus_delay;
    }
}

